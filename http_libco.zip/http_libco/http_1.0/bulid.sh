#!/bin/bash

make clean
make
make output
